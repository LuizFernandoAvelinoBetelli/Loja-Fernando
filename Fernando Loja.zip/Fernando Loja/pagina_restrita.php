<?php
session_start();

if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="pt_BR">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="page-header">
        <h1>Olá, <b><?php echo htmlspecialchars($_SESSION["username"]); ?>
        <br>
        </b>Bem-Vindo a área cadastro</h1>
    </div>
    <p>
        
        <a href="cadastro.php" class="btn btn-success">Cadastro de Produtos</a>
        <br><br>
        
        <a href="logout.php" class="btn btn-danger">Sair da conta</a>

         <a href="cadastrados.php" class="btn btn-warning"> Cadastrados</a>
    </p>
</body>
</html>