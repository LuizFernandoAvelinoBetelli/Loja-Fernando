<?php
session_start();

if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location:login.php");
    exit;
}
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $produto=$_POST['produto'];
    $preco_produto=$_POST['preco_produto'];
    $animal=$_POST['animal'];
    $nome_cliente=$_POST['nome_cliente'];
    $id_cliente=$_POST['id_cliente'];
    $preco_pago=$_POST['preco_pago'];
    $data_venda=$_POST['data_venda'];

    $handle = fopen("produtos_cadastrados.txt","a");
    fwrite($handle, $produto."\n");
    fwrite($handle, $preco_produto. "\n");
    fwrite($handle, $animal."\n");
    fwrite($handle, $nome_cliente. "\n");
    fwrite($handle, $id_cliente. "\n");
    fwrite($handle, $preco_pago. "\n");
    fwrite($handle, $data_venda. "\n");
    fclose($handle);
}
?>


<!DOCTYPE html>
<html lang="pt_BR">
<head>
    <meta charset="UTF-8">
    <title>CADASTRO</title>
    <link rel="stylesheet" href="style.css">

    <style>
       
        .wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 75vh;
            border: 2px solid #000;
            padding: 5px;
            margin:90px;
            background-color: #f2f2f2;
            font-family: Arial, sans-serif; /* Define uma fonte mais estilizada */

        }

        .botao {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 1px;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
            margin-left:center;
            margin-top:25px;
            font-family: Arial, sans-serif; /* Define uma fonte mais estilizada */
            font-weight: bold;

                        
        }
        .sair {
            display: inline-block;
            padding: 10px 20px;
            background-color: red; 
            color: white; /* Altera a cor do texto para branco */
            border-radius: 1px;
            text-decoration: none;
            font-size: 14px; 
            cursor: pointer;
            margin-right:center;
            font-family: Arial, sans-serif; /* Define uma fonte mais estilizada */
            font-weight: bold;

           
            }
        .cadastros{
            display: inline-block;
            padding: 10px 20px;
            background-color: #FFCC00; /* Altera a cor de fundo para vermelho */
            color: black; /* Altera a cor do texto para branco */
            border-radius: 1px;
            text-decoration: none;
            font-size: 14px; /* Aumenta o tamanho da fonte para 16px */
            cursor: pointer;            
            font-family: Arial, sans-serif; /* Define uma fonte mais estilizada */
            margin-left: 100px;
            font-weight: bold;

        }
      
        .produto{
            margin-top:20px;
            background-color: #f2f2f2;
            width: 200px;
            margin-left: 20px;
        }
        .preco{
            margin-top:20px;
            background-color: #f2f2f2;
            width: 200px;
            margin-left: 20px;
        }

        .animal{
            margin-top:20px;
            background-color: #f2f2f2;
            width: 200px;
            margin-left: 20px;
        }
        .cliente{
            margin-top:20px;
            background-color: #f2f2f2;
            width: 200px;
            margin-left: 20px;
        }

        .id{
            margin-top: 20px;
            background-color: #f2f2f2;
            width: 200px;
            margin-left: 20px;
        }
        .pago{
            margin-top:20px;
            background-color: #f2f2f2;
            width: 200px;
            margin-left: 20px;

        }
        .data{
            margin-top:20px;
            background-color: #f2f2f2;
            width: 200px;
            margin-left: 20px;
        }
        h2, p {
          font-family: Arial, sans-serif; /* Nova fonte */
          font-size: 20px;
          color:red;
          font-weight: bold;
        }

    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Cadastro</h2>
        <p>Informe nos campos abaixo, as informações necessarias.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Nome do Produto</label>
                <input type="text" name="produto" class="produto" value="">
                <span class="help-block"></span>
            </div> 
            <div class="form-group">
                <label>Preço do Produto</label>
                <input type="text" name="preco_produto" class="preco" value="R$:">
                <span class="help-block"></span>
            </div> 
            <div class="form-group">
                <label>Nome do Animal</label>
                <input type="text" name="animal" class="animal" value="" >
                <span class="help-block"></span>
            </div>
            <div class="form-group">
                <label>Nome do Cliente</label>
                <input type="text" name="nome_cliente" class="cliente" value="">
                <span class="help-block"></span>
            </div>   
            <div class="form-group">
                <label>Id do cliente</label>
                <input type="number" name="id_cliente" class="id" value="" >
                <span class="help-block"></span>
            </div> 
            <div class="form-group">
                <label>Preco pago pelo Cliente</label>
                <input type="text" name="preco_pago" class="pago" value="R$:">
                <span class="help-block"></span>
            </div> 
            <div class="form-group">
                <label>Data Venda</label>
                <input type="text" name="data_venda" class="data" value="" >
                <span class="help-block"></span>
            </div>
            <div class="form-group">
                <input type="submit" class="botao" value="Enviar">
            </div>

           
            <a href="logout.php" class="sair">Sair da conta</a>

            <a href="cadastrados.php" class="cadastros"> Cadastrados</a>
            
        </form>
    </div>    
</body>
</html>