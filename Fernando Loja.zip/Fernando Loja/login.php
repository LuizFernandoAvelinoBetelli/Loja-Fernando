<?php
 
 if($_SERVER["REQUEST_METHOD"] == "POST"){
     session_start();
     if($_POST['username'] == 'Fernando' and $_POST['password'] == 'casadofazendeiro'){
         $_SESSION['loggedin'] = TRUE;
         $_SESSION["username"] = 'Fernando';
          header("location: pagina_restrita.php");
     } else {
         $_SESSION['loggedin'] = FALSE;
     }
 }
 ?>

<!DOCTYPE html>
<html lang="pt_BR">
<head>
    <meta charset="UTF-8">
    <title>Acessar</title>
    <link rel="stylesheet" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
        .wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 75vh;
            border: 2px solid #000;
            padding: 5px;
            margin:90px;
            background-color: #f2f2f2;
            font-family: Arial, sans-serif; /* Define uma fonte mais estilizada */

        }
       
        .form-group {
            margin-bottom: 30px;
            font: 15px sans-serif; 

        }
         
        h2, p {
          font-family: Arial, sans-serif; /* Nova fonte */
            font-size: 25px;
            padding:30px;
        }

        .botao {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 1px;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
            margin-left:70px;
            
        }
        
        .botao:hover {
            background-color: #45a049;
        }

    body {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin-right:70px;

    }

    .carousel {
      width: 500px;
      height: 300px;
      overflow: hidden;
      position: relative;
    }

    .carousel img {
      width: 100%;
      height: 100%;
    }

    .carousel .slide {
      position: absolute;
      top: 0;
      left: 0;
      opacity: 0;
      transition: opacity 0.5s ease-in-out;
    }

    .carousel .slide.active {
      opacity: 1;
    }
  </style>
</head>

              <body>
                <div class="carousel">
                  <div class="slide active">
                    <img src="imagens/pet1.jpg" alt="Imagem 1">
                  </div>
                  <div class="slide">
                    <img src="imagens/pet2.jpg" alt="Imagem 2">
                  </div>
                  <div class="slide">
                    <img src="imagens/pet3.jpg" alt="Imagem 3">
                  </div>
                  <div class="slide">
                    <img src="imagens/pet4.jfif" alt="Imagem 4">
                  </div>
                  <div class="slide">
                    <img src="imagens/pet4.jfif" alt="Imagem 5">
                  </div>
                </div>

                <script>
                  document.addEventListener("DOMContentLoaded", function(event) {
                    const slides = document.querySelectorAll(".slide");
                    let currentSlide = 0;

                    function showSlide(index) {
                      slides.forEach(function(slide) {
                        slide.classList.remove("active");
                      });
                      slides[index].classList.add("active");
                    }

                    function nextSlide() {
                      currentSlide = (currentSlide + 1) % slides.length;
                      showSlide(currentSlide);
                    }

                    setInterval(nextSlide, 3000);
                  });
                </script>
              </body>

       

            <div class="wrapper"> 
                <p>Favor inserir usuário e senha</p>

                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                
                    <div class="form-group">
                        <label>LOGIN</label>
                        <input type="text" name="username" class="form-control" value="Fernando">
                        <span class="help-block"></span>
                    </div>    
                    <div class="form-group">
                        <label>SENHA</label>
                        <input type="password" name="password" class="form-control" value="casadofazendeiro">
                        <span class="help-block"></span>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="botao" value="Acessar">
                    </div>  
                        
                </form>
            </div>
        </body>
        </html>


